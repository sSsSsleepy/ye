import static org.junit.Assert.assertEquals;

import org.junit.Test;

public final class TestDice2ndary {
    @Test
    public final void testease1() {
        Dice d1 = new Dice1();
        while (d1.reportMin() > d1.reportFace() / 2) {
            d1.ease(1);
        }
        assertEquals(d1.reportFace() / 2, d1.reportMin());
    }

    @Test
    public final void testease2() {
        Dice d1 = new Dice1(20, 20);
        while (d1.reportMin() > d1.reportFace() / 2) {
            d1.ease(1);
        }
        assertEquals(d1.reportFace() / 2, d1.reportMin());
    }

    @Test
    public final void testtighten1() {
        Dice d1 = new Dice1();
        while (d1.reportMax() > d1.reportFace() + 1) {
            d1.tighten(1);
        }
        assertEquals(d1.reportFace() + 1, d1.reportMax());
    }

    @Test
    public final void testtighten2() {
        Dice d1 = new Dice1(30, 30);
        while (d1.reportMax() > d1.reportFace() + 1) {
            d1.tighten(1);
        }
        assertEquals(d1.reportFace() + 1, d1.reportMax());
    }

    @Test
    public final void testsetFace1() {
        Dice d1 = new Dice1();
        d1.setFace(10);
        assertEquals(10, d1.reportFace());
        assertEquals(d1.reportBase(), 1);
    }

    @Test
    public final void testsetFace2() {
        Dice d1 = new Dice1(10, 30);
        d1.setFace(20);
        assertEquals(20, d1.reportFace());
        assertEquals(d1.reportBase(), 10);
    }
    // Same here, other method involved in lots of UL and LL, so ...
}