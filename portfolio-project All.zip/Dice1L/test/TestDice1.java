import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public final class TestDice1 {
    @Test
    public final void testroll() {
        Dice d1 = new Dice1();
        int result = d1.roll();
        assertTrue(1 <= result && result <= 6);
    }

    @Test
    public final void testroll2() {
        Dice d1 = new Dice1(5, 5);
        int result = d1.roll();
        assertTrue(5 <= result && result <= 10);
    }

    // I have to use .reportFace() here since .equal() seems require same UL and LL
    @Test
    public final void testaddFace1() {
        Dice d1 = new Dice1();
        Dice d2 = new Dice1(1, 7);
        d1.addFace(1);
        assertEquals(d1.reportFace(), d2.reportFace());
    }

    @Test
    public final void testaddFace2() {
        Dice d1 = new Dice1(5, 5);
        Dice d2 = new Dice1(5, 7);
        d1.addFace(2);
        assertEquals(d1.reportFace(), d2.reportFace());
    }

    @Test
    public final void testremoveFace1() {
        Dice d2 = new Dice1(5, 5);
        Dice d1 = new Dice1(5, 7);
        d1.removeFace(2);
        assertEquals(d1.reportFace(), d2.reportFace());
    }

    @Test
    public final void testremoveFace2() {
        Dice d2 = new Dice1();
        Dice d1 = new Dice1(1, 7);
        d1.removeFace(1);
        assertEquals(d1.reportFace(), d2.reportFace());
    }

    @Test
    public final void testsetBase1() {
        Dice d2 = new Dice1();
        Dice d1 = new Dice1(3, 6);
        d1.setBase(1);
        assertEquals(d1.reportBase(), d2.reportBase());
        assertEquals(d1.reportFace(), d2.reportFace());
    }

    @Test
    public final void testsetBase2() {
        Dice d2 = new Dice1(5, 6);
        Dice d1 = new Dice1();
        d1.setBase(5);
        assertEquals(d1.reportBase(), d2.reportBase());
        assertEquals(d1.reportFace(), d2.reportFace());
    }

    @Test
    public final void testreportBase1() {
        Dice d1 = new Dice1();
        int i = 1;
        int x = d1.reportBase();
        assertEquals(i, x);
    }

    @Test
    public final void testreportBase2() {
        Dice d1 = new Dice1(6, 7);
        int i = 6;
        int x = d1.reportBase();
        assertEquals(i, x);
    }

    @Test
    public final void testreportFace1() {
        Dice d1 = new Dice1();
        int i = 6;
        int x = d1.reportFace();
        assertEquals(i, x);
    }

    @Test
    public final void testreportFace2() {
        Dice d1 = new Dice1(300, 100);
        int i = 100;
        int x = d1.reportFace();
        assertEquals(i, x);
    }

    @Test
    public final void testULchange1() {
        Dice d1 = new Dice1();
        int i = 7;
        d1.ULchange(i);
    }

    // I did not test other method about UL, LL because they have great randomness so it is really hard to
    // capture unless you use like sequence to check contain... that is not efficiency

}