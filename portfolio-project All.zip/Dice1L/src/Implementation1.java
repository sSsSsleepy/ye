import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

/**
 * Put a short phrase describing the program here.
 *
 * @author Put your name here
 *
 */
public final class Implementation1 {

    /**
     * No argument constructor--private to prevent instantiation.
     */
    //Dice in game
    // simple dice game, given two dice and determine who wins

    private static Dice buildFishingRod(int Rodlength, int hook) {
        return new Dice1(Rodlength, hook);
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {
        Dice d1 = buildFishingRod(10, 20);
        SimpleWriter out = new SimpleWriter1L();
        int count = 0;
        while (d1.result() == false) {
            count++;
            d1.result();
        }
        out.println("you took " + count + " time(s) to get a fish!");
        /*
         * Put your main program code here
         */
    }

}
