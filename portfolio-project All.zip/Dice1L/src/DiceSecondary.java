
public abstract class DiceSecondary implements Dice {

    @Override
    public boolean equals(Object obj) {
        boolean result = false;
        Dice ds = (Dice) obj;
        if (this == ds) {
            result = true;
        }
        if (this == null) {
            result = false;
        }
        if (!(ds instanceof Dice1)) {
            result = false;
        }
        if (this.reportFace() != ds.reportFace()) {
            result = false;
        }
        if (this.reportBase() != ds.reportBase()) {
            result = false;
        }
        // I am considering if I need to check the max and min (UL and LL) are the same
        //they seems to contain some degree of randomness
        if (this.reportMin() != ds.reportMin()) {
            result = false;
        }
        if (this.reportMax() != ds.reportMax()) {
            result = false;
        }
        return result;
    }

    @Override
    public int hashCode() {
        // I just use index as the hash int here
        // 5 is my favorite number and its prime so I use it here ;)
        return this.roll() * 5 + this.reportBase();
    }

    @Override
    public final boolean result() {
        return this.roll() >= (this.reportMax() + this.reportMin()) / 2;
    }

    @Override
    public final boolean punish(int i) {
        assert i > 0 : "Violation of: the point of punish must be positive";
        assert this.reportFace()
                - i >= 0 : "Violation of: this final result must greater or equal than zero";
        this.removeFace(i);
        return this.roll() >= (this.reportMax() + this.reportMin()) / 2;
    }

    @Override
    public final boolean boost(int i) {
        assert i > 0 : "Violation of: the point of boost must be positive";
        this.addFace(i);
        return this.roll() >= (this.reportMax() + this.reportMin()) / 2;
    }

    @Override
    public void ease(int i) {
        assert i > 0 : "Violation of: the point of ease must be positive";
        assert this.reportMin() >= this.reportFace()
                / 2 : "Violation of: You cannot change your range no more";
        this.ULchange(i);
        this.LLchange(-i);
    }

    @Override
    public void tighten(int i) {
        assert i > 0 : "Violation of: the point of tighten must be positive";
        assert this.reportMax() > this
                .reportFace() : "Violation of: You cannot change your range no more";
        this.ULchange(-i);
        this.LLchange(i);
    }

    @Override
    public void setFace(int i) {
        assert i > 0 : "Violation of: you cannot create a zero face dice!";
        int check = 0;
        if (i > this.reportFace()) {
            check = i - this.reportFace();
            for (int x = 0; x < check; x++) {
                this.addFace(1);
            }
        } else {
            check = this.reportFace() - i;
            for (int x = 0; x < check; x++) {
                this.removeFace(1);
            }
        }
    }

    @Override
    public int sizeOfPossibleRange() {
        //the size of the successful range
        return this.reportMax() - this.reportMin();
    }

    @Override
    public double expectation(int NumofFace) {

        assert NumofFace > 0 : "Violation of: you cannot create a zero face dice!";
        double result = 0;
        int mid = (this.reportMax() + this.reportMin()) / 2;

        if ((this.reportBase() + NumofFace) >= mid) {
//            if (Double.canParseDouble(((this.reportBase() + NumofFace) - mid)
//                    / (this.reportBase() + NumofFace))) {
            result = ((this.reportBase() + NumofFace) - mid)
                    / (this.reportBase() + NumofFace);
        }
//        }
        return result;
    }

}