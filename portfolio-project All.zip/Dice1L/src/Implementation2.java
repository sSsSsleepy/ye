import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

/**
 * Put a short phrase describing the program here.
 *
 * @author Put your name here
 *
 */
public final class Implementation2 {

    /**
     * No argument constructor--private to prevent instantiation.
     */
    //Dice in game
    // simple dice game, given two dice and determine who wins
    private static boolean Implementation(Dice yourDice, Dice BotDice) {
        boolean result = false;
        if (yourDice.roll() > BotDice.roll()) {
            result = true;
        }
        return result;
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {
        Dice d1 = new Dice1(10, 60);
        Dice d2 = new Dice1();
        boolean result = Implementation(d1, d2);
        SimpleWriter out = new SimpleWriter1L();
        if (result = true) {
            out.println("YOU WIN");
        } else {
            out.println("BOT WIN");
        }
        out.close();
        /*
         * Put your main program code here
         */
    }

}
