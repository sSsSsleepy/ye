import java.util.Random;

import components.sequence.Sequence;
import components.sequence.Sequence1L;

/**
 * {@code NaturalNumber} represented as 1. possibility range {two non-negative
 * integer} 2. sequence with n elements. (n = number of the size of the face)
 * sequence contains non-negative integer
 *
 * @convention <pre>
the minimum size of the range {the smaller integer} should >=
1/2 |sequence| (n/2) to ensure its difficulty
and maximum size of the range {the smaller integer} should >
|sequence| (n) to ensure its difficulty
and all the element in the sequence should start from the base
and increment by one with next index
and the base should >= 1
and all the integer should >= 0
</pre>
 * @correspondence <pre>
if result >= (Smaller int + Bigger int) / 2
then return result "success"
</pre>
 * @author Songyu Ye
 * @version 2024/4/19
 **/

// should I include <T> here since I have sequence in kernal?
public class Dice1 extends DiceSecondary {
    /**
     * Representation of two integer {@code integer}.
     */
    /**
     * lower Limit.
     */
    private int LL;
    /**
     * Upper Limit.
     */
    private int UL;

    /**
     * a normal dice has sides of 6.
     */
    final int normalDice = 6;

    /**
     * a normal dice start from 1.
     */
    final int normalBase = 1;

    /**
     * The dice to be rolled.
     */
    private Sequence<Integer> seq;

    /**
     * The number of faces of the dice.
     */
    private int face;

    /**
     * The base of the sequence.
     */
    private int Base;

    /**
     * Builds a sequence starting from the specified base value and having the
     * specified length. Each element in the sequence starts from the base value
     * and increments by one for each subsequent element.
     *
     * @param base
     *            the starting value of the sequence
     * @param length
     *            the length of the sequence to be generated
     * @return a sequence containing elements starting from the base value and
     *         incrementing by one
     * @requires base >= 1 and length >= 1
     * @ensures the resulting sequence contains 'length' elements starting from
     *          'base'
     */
    private static Sequence<Integer> buildSeq(int base, int length) {
        assert base >= 1 : "Violation of: base must be as least one";
        assert length >= 1 : "Violation of: size must be as least one";
        Sequence<Integer> s = new Sequence1L<Integer>();
        for (int i = 0; i < length; i++) {
            s.add(s.length(), base + i);
        }
        return s;
    }

    /**
     * Generates a random integer within the range of the given sequence.
     *
     * @param s
     *            The sequence from which to generate the random integer.
     * @ensures |s| > 0
     * @return A random integer within the range defined by the sequence.
     */
    private static int roll(Sequence<Integer> s) {
        assert s.length() >= 1 : "Violation of: length of sequence must >= 1";
        Random random = new Random();
        int base = s.entry(0);
        int maxFace = s.entry(s.length() - 1);
        int result = random.nextInt(base, maxFace);
        return result;
    }

    /**
     * Generates a random minimum value for a range based on the length.
     *
     * @param length
     *            The length of the sequence used to determine the range.
     * @return A random integer representing the minimum value of the range.
     * @ensures length > 0
     */
    private static int generateRangeMin(int length) {
        assert length >= 1 : "Violation of: length of sequence must >= 1 to generate the range";
        Random random = new Random();
        int result = random.nextInt(length / 2, length);
        return result;
    }

    /**
     * Generates a random minimum value for a range based on the length.
     *
     * @param length
     *            The length of the sequence used to determine the range.
     * @return A random integer representing the minimum value of the range.
     * @ensures length > 0
     */
    private static int generateRangeMax(int length) {
        assert length >= 1 : "Violation of: length of sequence must >= 1 to generate the range";
        Random random = new Random();
        int result = random.nextInt(length + 1, length * length);
        return result;
    }

    /**
     * Creator of initial representation.
     */
    private void createNewRep(int base, int face) {
        // should i set normalBase and Dice here?
        this.seq = buildSeq(base, face);
        this.LL = generateRangeMin(face);
        this.UL = generateRangeMax(face);
        this.Base = base;
        this.face = face;
    }

    /*
     * Constructors -----------------------------------------------------------
     */

    /**
     * Constructor from {@code int}.
     *
     * @param base
     *            {@code int} to initialize base
     * @param face
     *            {@code int} to initialize face
     */
    public Dice1(int base, int face) {
        this.createNewRep(base, face);
    }

    /**
     * No-argument constructor.
     *
     */
    public Dice1() {
        this.createNewRep(this.normalBase, this.normalDice);
    }

    @Override
    public final void transferFrom(Dice source) {
        Dice1 localSource = (Dice1) source;
        this.LL = localSource.LL;
        this.UL = localSource.UL;
        this.face = localSource.face;
        this.Base = localSource.Base;
        this.seq = localSource.seq;
        localSource.createNewRep(localSource.Base, localSource.face);
    }

    @Override
    public final Dice newInstance() {
        try {
            return this.getClass().getConstructor().newInstance();
        } catch (ReflectiveOperationException e) {
            throw new AssertionError(
                    "Cannot construct object of type " + this.getClass());
        }
    }

    @Override
    public final int roll() {
        return roll(this.seq);
    }

    // how to ensure face++ is add to the last of the sequence.
    @Override
    public final void addFace(int i) {
        assert i > 0 : "Violation of: base must be as least one";
        int y = 0;
        for (int x = i; x > 0; x--) {
            int finalInt = this.seq.length() - 1;
            y = this.seq.entry(finalInt);
            this.seq.add(this.seq.length(), y);
            this.face++;
        }
    }

    @Override
    public final void clear() {
        this.createNewRep(this.Base, this.face);
    }

    // is there any needs that I should return the removed face?
    @Override
    public final void removeFace(int i) {
        assert i > 0 : "Violation of: you cannot remove a negative number of face";
        assert this.face
                - i >= 1 : "Violation of: you are removing too much elements";
        for (int x = i; x > 0; x--) {
            this.seq.remove(this.seq.length() - 1);
            this.face--;
        }
    }

    @Override
    public final void setBase(int i) {
        assert i > 0 : "Violation of: base must be as least one";
        this.Base = i;
    }

    @Override
    public final int reportBase() {
        return this.Base;
    }

    //I add these method because it's hard to access the value of lower limit in secondary
    @Override
    public final int reportMin() {
        return this.LL;
    }

    @Override
    public final int reportFace() {
        return this.face;
    }

    @Override
    public final int reportMax() {
        return this.UL;
    }

    @Override
    public final void ULchange(int i) {
        assert this.UL
                + i > this.face : "Violation of Range: you change to much UL ";
        if (i > 0) {
            for (int x = 0; x < i; x++) {
                this.UL++;
            }
        } else {
            for (int x = 0; x > i; x--) {
                this.UL--;
            }
        }
    }

    @Override
    public final void LLchange(int i) {
        assert this.LL + i >= this.face
                / 2 : "Violation of Range: you change to much LL ";
        if (i > 0) {
            for (int x = 0; x < i; x++) {
                this.LL++;
            }
        } else {
            for (int x = 0; x > i; x--) {
                this.LL--;
            }
        }
    }

}
