/**
 * {@code NaturalNumberKernel} enhanced with secondary methods.
 */
public interface Dice extends DiceKernel {

    // I did not see the interface for equal and hashcode()?

    /**
     * Return the result of the dice, to check the result after
     * this.roll() is greater than (UL+LL） / 2 {@convention}
     * @return the result of the dice
     */
    boolean result();


    /**
    * Report the result after remove the biggest value face of the dice
     * @param i the number of faces to be removed
     * @requires  i > 0 && this.reportFace() - i >= 0
     * @ensures |this.seq| - i && this.reportFace() - i
     * @return the result of the dice after edited
     * */
boolean punish (int i);

/**
    * Report the result after add face to the dice
     * @param i the number of faces to be added
     * @requires  i > 0
     * @ensures |this.seq| + i && this.reportFace() + i
     * @return the result of the dice after edited
     * */
boolean boost (int i);

/**
 * Expand the possibility range
 * @param i the number of faces to be expanded
 * @requires i > 0
 * && this.reportMin() >= this.reportFace() / 2
 * @ensures the upper limit increase by i and lower limit decrease by i
 */
void ease (int i);

/**
 * shrink the possibility range
 * @param i the number of faces to be shrinked
 * @requires  i > 0 && this.reportMax() > this.reportFace()
 * @ensures the upper limit decrease by i and lower limit increase by i
 */
void tighten (int i);

/**
 * Set the face of the dice to i
 * @param i the number of faces to be setted
 * @requires  i > 0
 * @ensures |this.face| = i
 */
void setFace (int i);

/**
 * Report the possibility range size
 * @return the size of the range (this.UL - this.LL)
 */
int sizeOfPossibleRange();

/**
 * @param NumofFace The expect number of faces to put in the dice
 * @requires  NumofFace > 0
 * @return the double result of the caculate function
 *  ((base + NumofFace) - mid) / (base + NumofFace) the ratio of the sucuess range
 */
double expectation (int NumofFace);

}