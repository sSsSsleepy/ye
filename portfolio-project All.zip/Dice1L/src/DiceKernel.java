import components.standard.Standard;

/**
 * Dice kernel component with primary methods.
 *
 * @mathsubtypes <pre> DICE_MODEL is ( a {@code Sequence} with a
 *               base{@code Integer} and increment by one with mext index a
 *               {@code Integer} represent lower possibility a {@code Integer}
 *               represent upper possibility </pre>
 * @mathmodel type SequenceKernel is modeled by string of {@code Integer} ???
 * @param int
 *            face the points of face of dice
 * @param int
 *            LL the lower possibility limit //Need UL here?
 * @param int
 *            UL the upper possibility limit
 * @initially {@code
 * ():     @ensures this = <i, i+1,i+2,...,i+n> n >= 1 && i> 0 i is the base}
 * @ensures: LL >= |this.sequence| / 2 &&UL > |this.sequence| &&LL && UL > 0 }
 *           (index: int i): ensures this at index 0 = i )
 *
 */

public interface DiceKernel extends Standard<Dice> {
    /**
     * a normal dice has sides of 6.
     */
    final int normalDice = 6;

    /**
     * a normal dice start from 1.
     */
    final int normalBase = 1;

    /**
     * Return a random int in sequence.
     *
     * @return the integer from sequence
     * @requires |this.seq| > 0
     */
    int roll();

    /**
     * Add i number of face to the dice.
     *
     * @param i
     *            the number of faces to be added
     * @updates this.seq
     * @requires i > 0
     * @ensures this.face+i && this.seq increase length by i following the
     *          convention
     */
    void addFace(int i);

    /**
     * Remove i number of face to the dice.
     *
     * @updates this.seq
     * @param i
     *            the number of faces to be removed
     * @requires i > 0 && this.face - i >= 1
     * @ensures this.face-i && this.seq decrease length by i following the
     *          convention
     */
    void removeFace(int i);

    /**
     * Set the base of the sequence to i / the starting point of the dice to i.
     *
     * @updates this.base
     * @param i
     *            the number of base to be setted
     * @requires x > 0
     * @ensures this.base = i.
     */
    void setBase(int i);

    /**
     * report the base of the dice.
     *
     * @return this.base
     */
    int reportBase();

    /**
     * report the lower limit of the success range.
     *
     * @return this.LL
     */
    int reportMin();

    /**
     * report the upper limit of the success range.
     *
     * @return this.UL
     */
    int reportMax();

    /**
     * report the face of the dice.
     *
     * @return this.face
     */
    int reportFace();

    /**
     * Change the upper limit of the range by i.
     *
     * @param i
     *            the number of upper limit to be changed
     * @requires this.UL + i > this.face
     * @updates this.UL
     * @ensures this.UL + / - by i
     */
    void ULchange(int i);

    /**
     * Change the lower limit of the range by i.
     *
     * @param i
     *            the number of lower limit to be changed
     * @requires this.LL + i >= this.face / 2
     * @updates this.LL
     * @ensures this.LL + / - by i
     */
    void LLchange(int i);
}